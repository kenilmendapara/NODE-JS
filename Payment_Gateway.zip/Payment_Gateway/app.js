const express = require('express');
const bodyparser = require('body-parser');
const path = require('path');
const app = express();
const port = process.env.PORT || 1234;

const YOUR_DOMAIN = 'http://localhost:1234';

var Publishable_Key = 'pk_test_51MgMB4SCqeHF5bbP3AZFdV0jy9eCbIGzXCmJFjHv0m1NiWiwmw1sR5YBwcLtKo2UPS3JiIMFQlomPHjvzYY64k4R00XLkbXKLz';
var Secret_Key = 'sk_test_51MgMB4SCqeHF5bbPsG1KsUWwBh38vLGuiKN0S6hHAco3JiNkRlisAnVdqgvBrwkMCqNqbbR9ynFHofgsIQsgVFMx00TCwTQWeD';

const stripe = require('stripe')(Secret_Key);

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: false }));

app.use(express.static('public'));

// View Engine Setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.get('/', function (req, res) {
    res.render('checkout', {
        key: Publishable_Key
    })
})

app.post('/create-checkout-session', async (req, res) => {
    const session = await stripe.checkout.sessions.create({
      line_items: [
        {
          // Provide the exact Price ID (for example, pr_1234) of the product you want to sell
          price: 'price_1MgQ48SCqeHF5bbPjuEVL3Kx',
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${YOUR_DOMAIN}/success.ejs`,
      cancel_url: `${YOUR_DOMAIN}/cancel.ejs`,
    });
  
    res.redirect(303, session.url);
  });

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});




