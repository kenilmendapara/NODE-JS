const express = require('express');
const app = express();
const port = process.env.PORT || 2020;

const route = require('./routes/route')
app.use('/', route);

app.listen(port, () => {
    console.log(`server is listening on http://localhost:${port}`);
});