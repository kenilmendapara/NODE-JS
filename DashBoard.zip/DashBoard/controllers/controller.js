//<<<----- For Get Home Page----->>>
const getHomePage = async (req, res) => {
    try {

        res.render('dashboard', { title : "Dashboard"})

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Login Page----->>>
const getLoginPage = async (req, res) => {
    try {

        res.render('login', { title: "Login" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Register Page----->>>
const getRegisterPage = async (req, res) => {
    try {

        res.render('register', { title: "Register" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get 404 Page----->>>
const getError404Page = async (req, res) => {
    try {

        res.render('404-error', { title: "404 error" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get 500 Page----->>>
const getError500Page = async (req, res) => {
    try {

        res.render('500-error', { title: "500 server error" })

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Get Dashboard Page----->>>
const getDashboard = async (req, res) => {
    try {

        res.render('dashboard', { title: "Dashboard" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get List Page----->>>
const getShowList = async (req, res) => {
    try {

        res.render('list', { title: "List" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Add New Page----->>>
const getAddNew = async (req, res) => {
    try {

        res.render('add', { title: "Add new" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Edit Page----->>>
const getEditPage = async (req, res) => {
    try {

        res.render('edit', { title: "Edit" })

    } catch (error) {

        console.log(error.message);

    }
};



module.exports = {

    getHomePage,
    getLoginPage,
    getRegisterPage,
    getError404Page,
    getError500Page,
    getDashboard,
    getShowList,
    getAddNew,
    getEditPage

}