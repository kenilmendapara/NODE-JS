require('./models/db');

const express = require('express');
const path = require('path');
const exphbs = require('express-handlebars');
const bodyparser = require('body-parser');
const port = 3666;

const customerController = require('./controllers/customerController');
const serviceController = require('./controllers/serviceController');


var app = express();

//<<<------set body-parser------>>>
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({
    extended: true
}));

//<<<------set view engine------>>>
app.set('views', path.join(__dirname, '/views/'));
app.engine('hbs', exphbs.engine({ extname: 'hbs', defaultLayout: 'mainLayout', layoutsDir: __dirname + '/views/layouts' }));
app.set('view engine', 'hbs');

//<<<------Home Routes------>>>
app.get('/Home', (req, res) => {
    res.render('home');
});

//<<<------Customer Routes------>>>
app.use('/customer', customerController);


//<<<------Service Routes------>>>
app.use('/service', serviceController);


//<<<------Server Listening------>>>
app.listen(port, () => {
    console.log(`Express server started at http://localhost:${port}/Home`);
});

