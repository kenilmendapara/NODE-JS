const mongoose = require('mongoose');

var serviceSchema = new mongoose.Schema({
    customerName: {
        type: String,
    },
    vehicleNumber: {
        type: String
    },
    pickUpDate: {
        type: Date
    },
    dropDate: {
        type: Date
    },
    location: {
        type: String
    },
    serviceLocation: {
        type: Date
    },
    servicePrice: {
        type: Number 
    },
    paybleAmount: {
        type: Number
    }

});

mongoose.model('Service', serviceSchema);