const mongoose = require('mongoose');

var customerSchema = new mongoose.Schema({
    fullName: {
        type: String,
    },
    email: {
        type: String
    },
    mobile: {
        type: String
    },
    country: {
        type: String
    },
    birthdate: {
        type: Date
    },
    Address: {
        type: String
    },
    password: {
        type: String
    },
    cpassword: {
        type: String
    }

});

mongoose.model('Customer', customerSchema);