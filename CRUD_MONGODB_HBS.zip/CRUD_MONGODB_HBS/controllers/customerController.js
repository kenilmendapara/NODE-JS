const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const Customer = mongoose.model('Customer');
const list =[];

router.get('/', (req, res) => {
    res.render("customer/addOrEdit", {
        viewTitle: "Insert Customer"
    });
});

router.post('/', (req, res) => {
    if (req.body._id == '')
        insertRecord(req, res);
    else
        updateRecord(req, res);
});


function insertRecord(req, res) {
    var customer = new Customer();
    customer.fullName = req.body.fullName;
    customer.email = req.body.email;
    customer.mobile = req.body.mobile;
    customer.country = req.body.country;
    customer.city = req.body.birthdate;
    customer.city = req.body.address;
    customer.city = req.body.password;
    customer.city = req.body.cpassword

    customer.save((err, doc) => {
        if (!err)
            res.redirect('customer/list');
        else {
            console.log('Error during record insertion : ' + err);
        }
    });
}

function updateRecord(req, res) {
    Customer.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
        if (!err) { res.redirect('customer/list'); }
        else {
            console.log('Error during record update : ' + err);
        }
    });
}


router.get('/list', (req, res) => {
    Customer.find((err, docs) => {
        if (!err) {
             //console.log(docs);
            res.render("customer/list", {
                list: docs
                
            });
        }
        else {
            console.log('Error in retrieving customer list :' + err);
        }
        //console.log(list);
    });
});

router.get('/:id', (req, res) => {
    console.log(req.params.id);
    Customer.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render("customer/addOrEdit", {
                viewTitle: "Update Customer",
                customer: doc
            });
        }
    });
});

router.get('/delete/:id', (req, res) => {
    Customer.findByIdAndRemove(req.params.id, (err, doc) => {
       
        if (!err) {
            res.redirect('/customer/list');
        }
        else { console.log('Error in customer delete :' + err); }
    });
});

module.exports = router;