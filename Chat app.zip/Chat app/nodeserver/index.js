
const io = require('socket.io')(8888);

const users = {};

io.on('connection', socket => {

    //<<<----- For new user join, others know ----->>>
    socket.on('new-user-joined', name => {
        users[socket.id] = name;
        socket.broadcast.emit('user-joined', name);
    });

    //<<<----- For user send msg, broadcast to all ----->>>
    socket.on('send', message => {
        socket.broadcast.emit('recieve', { message: message, name: users[socket.id] });
    });

    //<<<----- For user left chat, broadcast to all ----->>>
    socket.on('disconnect', message => {
        socket.broadcast.emit('left', users[socket.id]);
        delete users[socket.id];
    });

})