const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const customers = mongoose.model('customers');

router.get('/', (req, res) => {
    res.render("customers/addOrEdit", {
        viewTitle: "Insert customers"
    });
});

router.post('/', (req, res) => {
    if (req.body._id == '')
        insertRecord(req, res);
    else
        updateRecord(req, res);
});


function insertRecord(req, res) {
    var customers = new customers();
    customers.fullName = req.body.fullName;
    customers.email = req.body.email;
    customers.mobile = req.body.mobile;
    customers.country = req.body.country;
    customers.city = req.body.birthdate;
    customers.city = req.body.address;
    customers.city = req.body.password;
    customers.city = req.body.cpassword

    customers.save((err, doc) => {
        if (!err)
            res.redirect('customers/list');
        else {
            console.log('Error during record insertion : ' + err);
        }
    });
}

function updateRecord(req, res) {
    customers.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
        if (!err) { res.redirect('customers/list'); }
        else {
            console.log('Error during record update : ' + err);
        }
    });
}


router.get('/list', (req, res) => {
    customers.find((err, docs) => {
        if (!err) {
             //console.log(docs);
            res.render("customers/list", {
                list: docs
                
            });
        }
        else {
            console.log('Error in retrieving customers list :' + err);
        }
        //console.log(list);
    });
});

router.get('/:id', (req, res) => {
    console.log(req.params.id);
    customers.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render("customers/addOrEdit", {
                viewTitle: "Update customers",
                customers: doc
            });
        }
    });
});

router.get('/delete/:id', (req, res) => {
    customers.findByIdAndRemove(req.params.id, (err, doc) => {
       
        if (!err) {
            res.redirect('/customers/list');
        }
        else { console.log('Error in customers delete :' + err); }
    });
});

module.exports = router;