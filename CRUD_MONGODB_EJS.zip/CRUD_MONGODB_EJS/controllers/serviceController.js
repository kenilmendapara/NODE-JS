const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const Service = mongoose.model('Service');

router.get('/', (req, res) => {
    res.render("service/addOrEdit", {
        viewTitle: "Insert Service"
    });
});

router.post('/', (req, res) => {
    if (req.body._id == '')
        insertRecord(req, res);
    else
        updateRecord(req, res);
});


function insertRecord(req, res) {
    var service = new Service();
    service.customerName = req.body.customerName;
    service.vehicleNumber = req.body.vehicleNumber;
    service.pickUpDate = req.body.pickUpDate;
    service.dropDate = req.body.dropDate;
    service.location = req.body.location;
    service.serviceLocation = req.body.serviceLocation;
    service.servicePrice = req.body.servicePrice;
    service.paybleAmount = req.body.paybleAmount

    service.save((err, doc) => {
        if (!err)
            res.redirect('service/list');
        else {
            console.log('Error during record insertion : ' + err);
        }
    });
}

function updateRecord(req, res) {
    Service.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
        if (!err) { res.redirect('service/list'); }
        else {
            console.log('Error during record update : ' + err);
        }
    });
}


router.get('/list', (req, res) => {
    Service.find((err, docs) => {
        if (!err) {
            //console.log(docs);
            res.render("service/list", {
                list: docs
            });
        }
        else {
            console.log('Error in retrieving service list :' + err);
        }
    });
});


router.get('/:id', (req, res) => {
    Service.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render("service/addOrEdit", {
                viewTitle: "Update Service",
                service: doc
            });
        }
    });
});

router.get('/delete/:id', (req, res) => {
    Service.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) {
            res.redirect('/service/list');
        }
        else { console.log('Error in service delete :' + err); }
    });
});

module.exports = router;