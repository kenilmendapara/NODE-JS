require('./models/db');

const express = require('express');
const path = require('path');
const ejs = require('ejs');
const bodyparser = require('body-parser');
const port = 3700;

const customersController = require('./controllers/customersController');
const serviceController = require('./controllers/serviceController');


var app = express();

//<<<------set body-parser------>>>
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({
    extended: true
}));

//<<<------set view engine------>>>
app.set('views', path.join(__dirname, '/views/'));
//app.engine('ejs', ejs.({ extname: 'ejs', defaultLayout: 'mainLayout', layoutsDir: __dirname + '/views/layouts' }));
app.set('view engine', 'ejs');

//<<<------Home Routes------>>>
app.get('/Home', (req, res) => {
    res.render('home');
});

//<<<------customers Routes------>>>
app.use('/customers', customersController);


//<<<------Service Routes------>>>
app.use('/service', serviceController);


//<<<------Server Listening------>>>
app.listen(port, () => {
    console.log(`Express server started at http://localhost:${port}/Home`);
});

