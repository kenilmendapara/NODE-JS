const User = require('../models/userModel');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
const randomstring = require('randomstring');
const config = require('../config/config');

//<<<----- For Password Bcrypt ----->>>
const securePassword = async (password) => {
    try {

        const passwordHash = await bcrypt.hash(password, 10);
        return passwordHash;

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Display Registration Page ----->>>
const sendVerifyMail = async (username, email, user_id) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });

        
        
        const mailOptions = {
            from: config.emailUser,
            to: email,
            subject: 'For Varification E-mail',
            html: '<p>Hii ' + username + ', Please click here to <a href="http://localhost:7777/verify?id=' + user_id + '"> verify </a> your mail.</p>'
        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For Display Registration Page ----->>>
const register = async (req, res) => {
    try {

        res.render('registration', { title: 'Registration' });

    } catch (error) {

        console.log(error.message);
    }
};



//<<<----- For Insert User ----->>>
const insertUser = async (req, res) => {

    try {

        const spassword = await securePassword(req.body.password)

        const user = new User({
            username: req.body.username,
            email: req.body.email,
            mobileno: req.body.mobileno,
            gender: req.body.gender,
            birthdate: req.body.birthdate,
            image: req.body.image,
            password: spassword,
            is_admin: 0

        });

        const userData = await user.save();

        if (userData) {
            sendVerifyMail(req.body.username, req.body.email, userData._id);

            res.render('registration', { title: 'Registration', message: 'Your Registration has been successfully, Please Verify email' });
        } else {
            res.render('registration', { title: 'Registration', message: 'Your Registration has been failed..' });
        }

    } catch (error) {

        console.log(error.message);

    }
};



//<<<----- For Verify Mail ----->>>
const verifyMail = async (req, res) => {

    try {

        const updatedInfo = await User.updateOne({ _id: req.query.id }, { $set: { is_verified: 1 } });
        res.render('email-verified', { title: 'Email Verified', message: 'Your mail has been verified...' })

    } catch (error) {

        console.log(error.message);
    }
};



//<<<----- For Display Login Page----->>>
const login = async (req, res) => {

    try {

        res.render('login', { title: 'Login' });

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Verify Login User ----->>>
const verifyLogin = async (req, res) => {

    try {

        const email = req.body.email;
        const password = req.body.password;

        const userData = await User.findOne({ email: email });

        if (userData) {
            const passwordMatch = await bcrypt.compare(password, userData.password);

            if (passwordMatch) {
                if (userData.is_verified === 0) {
                    res.render('login', { title: 'Login', message: 'Please Verify your Email..' });
                } else {

                    req.session.user_id = userData._id;
                    res.redirect('/home');
                }

            } else {
                res.render('login', { title: 'Login', message: 'Your Password Is Incorrect' });
            }

        }
        else {
            res.render('login', { title: 'Login', message: ' Your E-mail Is Incorrect' });
        }

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For Display Home Page ----->>>
const home = async (req, res) => {

    try {

        const userData = await User.findById({ _id: req.session.user_id });
        res.render('home', { title: 'Home', user: userData });

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For User LogOut ----->>>
const userLogout = async (req, res) => {

    try {

        req.session.destroy();
        res.redirect('/');

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Display forget Page ----->>>
const forget = async (req, res) => {

    try {

        res.render('forget', { title: 'Forget' });

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Forget Email Verify ----->>>
const forgetVerify = async (req, res) => {

    try {

        const email = req.body.email;
        const userData = await User.findOne({ email: email });

        if (userData) {

            if (userData.is_verified === 0) {

                res.render('forget', { title: 'Forget', message: 'Please Verify your Email..' });

            } else {

                const randomString = randomstring.generate();
                const updatedData = await User.updateOne({ email: email }, { $set: { token: randomString } });
                sendResetPasswordMail(userData.username, userData.email, randomString);
                res.render('forget', { title: 'Forget', message: 'Please check your mail to reset password.' });
            }

        } else {
            res.render('forget', { title: 'Forget', message: "Your E-mail is Incorrect" });
        }


    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Reset Password Send Email ----->>>
const sendResetPasswordMail = async (username, email, token) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });

        const mailOptions = {
            from: config.emailUser,
            to: email,
            subject: 'For Reset Password',
            html: '<p>Hii ' + username + ', Please click here to <a href="http://localhost:7777/forget-password?token=' + token + '"> Reset </a> your Password.</p>'
        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For New Password Set ----->>>
const forgetPassword = async (req, res) => {

    try {

        const token = req.query.token;
        const tokenData = await User.findOne({ token: token });
        if (tokenData) {

            res.render('forget-password', { title: 'New Password', user_id: tokenData._id });

        } else {

            res.render('404', { title: '404 Page Not Found', message: 'Your Token Is Invalid.' });

        }


    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Set Updated Password  ----->>>
const resetPassword = async (req, res) => {

    try {

        const password = req.body.password;
        const user_id = req.body.user_id;

        const secure_password = await securePassword(password);

        const updatedData = await User.findByIdAndUpdate({ _id: user_id }, { $set: { password: secure_password }, token: "" });

        if (updatedData) {

            res.redirect('/login');
        }


    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- User Profile Edit & Update ----->>>
const edit = async (req, res) => {

    try {

        const id = req.query.id;

        const userData = await User.findById({ _id: id });

        if (userData) {

            res.render('edit', { title: "Edit User", user: userData });

        } else {

            res.redirect('/home');
        }

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For User Profile Update ----->>>
const updateProfile = async (req, res) => {

    try {

        const userData = await User.findByIdAndUpdate({ _id: req.body.user_id },
            {
                $set: {

                    username: req.body.username,
                    email: req.body.email,
                    mobileno: req.body.mobileno,
                    gender: req.body.gender,
                    birthdate: req.body.birthdate,
                    image: req.body.image

                }
            });
            res.redirect('/home')
    } catch (error) {

        console.log(error.message);

    }
};

module.exports = {
    register,
    insertUser,
    verifyMail,
    login,
    verifyLogin,
    home,
    userLogout,
    forget,
    forgetVerify,
    forgetPassword,
    resetPassword,
    edit,
    updateProfile
};