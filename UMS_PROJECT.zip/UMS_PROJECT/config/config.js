const sessionSecret = "mysitesessionsecret";
const emailUser = 'kenilpatel1552@gmail.com';
const emailPassword = 'ysobvfmfwmkguaos'; 

module.exports = {
    sessionSecret,
    emailUser,
    emailPassword
}