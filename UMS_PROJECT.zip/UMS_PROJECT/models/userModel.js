const mongoose = require('mongoose');
const validator = require('validator')

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        // unique: true,
        // require: true,
        // trim : true,
        // minlength : [2, "username is has minimum 2 letter"],
        // maxlength : [20, "username is has maximum 20 letter"]
    },
    email: {
        type: String,
        // unique: true,
        // require: true,
        // trim : true,
        // validate(value){
        //     if(!validator.isEmail(value)){
        //         throw new Error("Email is Invalid.")
        //     }
        // }

    },
    mobileno: {
        type: Number,
        // unique: true,
        // require: true,
        // minlength : [10, "username is has minimum 10 letter"],
        // maxlength : [12, "username is has maximum 12 letter"]
    },
    gender: {
        type: String,
        // require: true
    },
    birthdate: {
        type: Date,
        // require : true,
        // validate(value){
        //     if(!validator.isDate(value)){
        //         throw new Error("Date is Invalid.")
        //     }
        // }
    },
    image: {
        type: String,
        // require: true
    },
    password: {
        type: String,
        // require: true,
        // validate(value){
        //     if(!validator.isStrongPassword(value)){
        //         throw new Error("Date is Invalid.")
        //     }
        // }
    },
    is_admin: {
        type: Number,
        // require: true
    },
    is_verified: {
        type: Number,
        default: 0,
        // require: true
    },
    token: {
        type: String,
        default : ''
    }
});

module.exports = mongoose.model('User', userSchema);