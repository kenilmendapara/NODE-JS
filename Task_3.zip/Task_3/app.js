const mongoose = require('mongoose');
mongoose.connect("mongodb://localhost:27017/UMS_Task-3", {
    useNewUrlParser: true
});


const express = require('express');
const app = express();
const port = process.env.PORT || 5555;

const user_route = require('./routes/userRout')
app.use('/', user_route);

app.listen(port, () => {
    console.log(`server is listening on http://localhost:${port}`);
});