
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const user_route = express();
const config = require('../config/config');
const auth = require('../middleware/auth');

const session = require('express-session');
user_route.use(session({ secret: config.sessionSecret }));

const static_path = path.join(__dirname, "../public");
user_route.use(express.static(static_path));

user_route.use(bodyParser.json());
user_route.use(bodyParser.urlencoded({ extended: true }));

user_route.set('view engine', 'ejs');
user_route.set('views', './views/users');

const userController = require('../controllers/userController');

user_route.get('/verify', auth.isLogout, userController.verifyMailOtp);
user_route.post('/verify', auth.isLogout, userController.verifiedMailOtp);

user_route.get('/', auth.isLogout, userController.login);
user_route.get('/login', auth.isLogout, userController.login);
user_route.post('/login', auth.isLogout, userController.verifyLogin);

user_route.get('/register', auth.isLogout, userController.register);
user_route.post('/register', auth.isLogout, userController.insertUser);

user_route.get('/forget', auth.isLogout, userController.forget);
user_route.post('/forget', auth.isLogout, userController.forgetVerify);

user_route.get('/forget-password', auth.isLogout, userController.forgetPassword);
user_route.post('/forget-password', auth.isLogout, userController.resetPassword);

user_route.get('/listService', auth.isLogin, userController.listService);

user_route.get('/addService', auth.isLogin, userController.service);
user_route.post('/addService', auth.isLogin, userController.addService);

user_route.get('/logout', auth.isLogin, userController.userLogout);
user_route.get('/create-pdf',  userController.createPdf);
user_route.get('/pdf-generate',  userController.pdfGenerate);

user_route.get('/editService/:id', auth.isLogin, userController.editService);
user_route.post('/editService', auth.isLogin, userController.updateService);

user_route.get('/deleteService/:id', auth.isLogin, userController.deleteService);

module.exports = user_route;