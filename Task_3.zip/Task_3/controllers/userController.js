const User = require('../models/customerModel');
const Service = require('../models/serviceModel');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const ejs = require('ejs');
const puppeteer = require('puppeteer')
const path = require('path');
const fs = require('fs');

//<<<----- For Password Bcrypt ----->>>
const securePassword = async (password) => {
    try {

        const passwordHash = await bcrypt.hash(password, 10);
        return passwordHash;

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Display Login Page----->>>
const login = async (req, res) => {

    try {

        res.render('login', { title: 'Login' });

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Display Register Page----->>>
const register = async (req, res) => {

    try {

        res.render('registration', { title: 'Register' });

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Insert User ----->>>
const insertUser = async (req, res) => {

    try {

        const spassword = await securePassword(req.body.password)

        const user = new User({
            username: req.body.username,
            email: req.body.email,
            mobileno: req.body.mobileno,
            gender: req.body.gender,
            birthdate: req.body.birthdate,
            address: req.body.address,
            password: spassword,
            usertype: req.body.usertype

        });

        const token = await user.generateAuthToken();

        const userData = await user.save();

        if (userData) {
            sendVerifyMail(req.body.username, req.body.email, userData._id);

            res.render('registration', { title: 'Registration', message: 'Your Registration has been successfully, Please Verify email' });
        } else {
            res.render('registration', { title: 'Registration', message: 'Your Registration has been failed..' });
        }

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Mail Varification ----->>>
const sendVerifyMail = async (username, email, _id) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });

        let otp = Math.floor(1000 + Math.random() * 9000);
        const updatedInfo = await User.updateOne({ email: email }, { $set: { otp: otp } });

        const mailOptions = {

            from: config.emailUser,
            to: email,
            subject: 'For Varification E-mail',
            html: '<p>Hii ' + username + ', Please click here to <a href="http://localhost:5555/verify?id=' + _id + '"> verify </a> your mail. your opt is ' + otp + ' </p>'

        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};

//<<<----- For Display Verify Page----->>>
const verifyMailOtp = async (req, res) => {

    try {

        res.render('verifyMailOtp', { title: 'Verification' });

    } catch (error) {

        console.log(error.message);

    }
};



//<<<----- For Verify Mail & Otp ----->>>
const verifiedMailOtp = async (req, res) => {

    try {

        const email = req.body.email;
        const otp = req.body.otp;

        const userData = await User.findOne({ email: email });
        if (userData) {

            const updatedInfo = await User.updateOne({ email: email }, { $set: { is_verified: 1 } });
            res.render('verifyMailOtp', { title: 'Email Verified', message: 'Your mail has been verified...' })


        }

    } catch (error) {

        console.log(error.message);
    }
};


//<<<----- For Verify Login User ----->>>
const verifyLogin = async (req, res) => {

    try {

        const email = req.body.email;
        const password = req.body.password;
        const userData = await User.findOne({ email: email });

        if (userData) {

            const passwordMatch = await bcrypt.compare(password, userData.password);
            //const token = await User.generateAuthToken();

            if (passwordMatch) {
                if (userData.is_verified === 0) {

                    res.render('login', { title: 'Login', message: 'Please Verify your Email..' });


                } else {

                    if (userData.usertype === 'customer') {

                        req.session._id = userData._id;
                        Service.find({ email: email }, (err, docs) => {
                            if (!err) {

                                res.render('customerHome', { title: 'Services', list: docs });
                            }
                            else {
                                console.log('Error in retrieving customers list :' + err);
                            }
                        });

                    } else {

                        req.session._id = userData._id;
                        res.redirect('/listService');

                    }
                }

            } else {
                res.render('login', { title: 'Login', message: 'Your Details Is Incorrect' });
            }

        }
        else {
            res.render('login', { title: 'Login', message: ' Your Details Is Incorrect' });
        }

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For Display forget Page ----->>>
const forget = async (req, res) => {

    try {

        res.render('forget', { title: 'Forget' });

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Forget Email Verify ----->>>
const forgetVerify = async (req, res) => {

    try {

        const email = req.body.email;
        const userData = await User.findOne({ email: email });

        if (userData) {

            if (userData.is_verified === 0) {

                res.render('forget', { title: 'Forget', message: 'Please Verify your Email..' });

            } else {

                const token = userData.token
                sendResetPasswordMail(userData.username, userData.email, token);
                res.render('forget', { title: 'Forget', message: 'Please check your mail to reset password.' });
            }

        } else {
            res.render('forget', { title: 'Forget', message: "Your E-mail is Incorrect" });
        }


    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Reset Password Send Email ----->>>
const sendResetPasswordMail = async (username, email, token) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });

        const mailOptions = {
            from: config.emailUser,
            to: email,
            subject: 'For Reset Password',
            html: '<p>Hii ' + username + ', Please click here to <a href="http://localhost:5555/forget-password?token=' + token + '"> Reset </a> your Password.</p>'
        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For New Password Set ----->>>
const forgetPassword = async (req, res) => {

    try {

        const token = req.query.token;
        const tokenData = await User.findOne({ token: token });
        if (tokenData) {

            res.render('forget-password', { title: 'New Password', _id: tokenData._id });

        } else {

            res.render('404', { title: '404 Page Not Found', message: 'Your Token Is Invalid.' });

        }


    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Set Updated Password  ----->>>
const resetPassword = async (req, res) => {

    try {

        const password = req.body.password;
        const _id = req.body._id;

        const secure_password = await securePassword(password);

        const updatedData = await User.findByIdAndUpdate({ _id: _id }, { $set: { password: secure_password }, token: "" });

        if (updatedData) {

            res.redirect('/login');
        }


    } catch (error) {

        console.log(error.message);

    }
};



//<<<----- For Display Add Service Page ----->>>
const service = async (req, res) => {

    try {

        res.render('serviceAdd', { title: 'service' });

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Insert New Service ----->>>
const addService = async (req, res) => {

    try {

        const service = new Service({
            vehicleNumber: req.body.vehicleNumber,
            email: req.body.email,
            pickUpDate: req.body.pickUpDate,
            dropDate: req.body.dropDate,
            location: req.body.location

        });

        const serviceData = await service.save();

        if (serviceData) {
            sendServiceMail(req.body.email, serviceData._id);
            res.render('serviceAdd', { title: 'serviceAdd', message: 'Your Data Add SuccesFully..' });
        } else {
            res.render('serviceAdd', { title: 'serviceAdd', message: 'Your Data Add Failed' });
        }

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Service Add Mail ----->>>
const sendServiceMail = async (email, _id) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });
        const mailOptions = {

            from: config.emailUser,
            to: email,
            subject: 'For Varification E-mail',
            html: '<p>Hii, Your service add Successfully... Thank You.....</P>'

        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};



//<<<----- For Display All Services Page ----->>>
const listService = async (req, res) => {

    Service.find((err, docs) => {
        if (!err) {

            res.render('serviceList', { title: 'Services', list: docs });
        }
        else {
            console.log('Error in retrieving customers list :' + err);
        }
    });
};


//<<<----- For Show Edit Service Page ----->>>
const editService = async (req, res) => {

    try {
        console.log(req.params.id);
        Service.findById(req.params.id, (err, doc) => {
            if (!err) {
                res.render("editService", {
                    title: "Edit Service",
                    service: doc
                });
            }
        });

    } catch (error) {

        console.log(error.message);

    }


};


//<<<----- For User LogOut ----->>>
const userLogout = async (req, res) => {

    try {

        req.session.destroy();
        res.redirect('/');

    } catch (error) {

        console.log(error.message);

    }
};



//<<<----- For Update Service ----->>>
const updateService = async (req, res) => {

    try {
        Service.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
            if (!err) {
                res.redirect('/listService');
            }
            else {
                console.log('Error during record update : ' + err);
            }
        });
    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Delete Service ----->>>
const deleteService = async (req, res) => {

    try {
        Service.findByIdAndRemove(req.params.id, (err, doc) => {
            if (!err) {
                res.redirect('/listService');
            }
            else { console.log('Error in service delete :' + err); }
        });
    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- Create Pdf file ----->>>
const createPdf = async (req, res) => {

    Service.find((err, docs) => {
        if (!err) {

            res.render('toPdf', { title: 'Services', list: docs });
        }
        else {
            console.log('Error in retrieving customers list :' + err);
        }
    });
};


//<<<----- Generate Pdf file ----->>>
const pdfGenerate = async (req, res) => {

    try {

        const browser = await puppeteer.launch();
        const page = await browser.newPage();

        await page.goto("http://localhost:5555/create-pdf", {
            waitUntill: "networkkidle2"
        });

        await page.setViewport({ width: 1080, height: 1050 });
        const todayDate = new Date();

        const pdf = await page.pdf({
            path: `${path.join(__dirname, '../public/file', todayDate.getTime() + ".pdf")}`,
            printBackground: true,
            format: "A4"

        });

        await browser.close();

        const pdfURL = path.join(__dirname, '../public/file', todayDate.getTime() + ".pdf");

        // res.set({
        //     "Content-Type": "application/pdf",
        //     "Content-Length": pdf.length
        // })
        // res.sendFile(pdfURL);

        res.download(pdfURL)

    } catch (error) {

        console.log(error.message);

    }
};




module.exports = {
    login,
    register,
    insertUser,
    verifyMailOtp,
    verifiedMailOtp,
    verifyLogin,
    forget,
    forgetVerify,
    service,
    addService,
    listService,
    forgetPassword,
    resetPassword,
    userLogout,
    editService,
    updateService,
    deleteService,
    createPdf,
    pdfGenerate
};