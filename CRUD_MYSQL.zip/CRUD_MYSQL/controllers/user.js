const connection = require("../models/connection");


//<<<------Display all users------>>>
exports.appGetShowUser = (req, res) => {
    let sql = "SELECT * FROM users";
    let query = connection.query(sql, (err, rows) => {
        if (err) {
            throw err;
        }
        else {
            res.render('index', {
                title: 'users',
                users: rows
            });
        }
    });
}


//<<<------Add new User------>>>
exports.appGetAddUser = (req, res) => {
    res.render('add', {
        title: 'Add User'
    });
}


//<<<------Insert user in database------>>>
exports.appPostInsertUser = (req, res) => {
    console.log(req.body);
    let data = {
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        gender: req.body.gender,
        mobileno: req.body.mobileno,
        birthdate: req.body.birthdate,
        bloodgroup: req.body.bloodgroup,
        address: req.body.address

    };
    let sql = "INSERT INTO users SET ?";
    let query = connection.query(sql, data, (err, results) => {
        if (err) {
            throw err;
        }
        else {
            res.redirect('/user');
        }
    });
}

//<<<------Edit user details in database------>>>
exports.appGetEditUser = (req, res) => {
    const userId = req.params.userId;
    console.log(userId);
    let sql = `Select * from users where userId = ${userId}`;
    console.log(sql);
    let query = connection.query(sql, (err, result) => {
        if (err) {
            throw err;
        }
        else {
            res.render('edit', {
                title: 'Edit User',
                user: result[0]
            });
        }
    });
}


//<<<------Update user in database------>>>
exports.appPostUpdateUser = (req, res) => {
    const userId = req.body.userId;
    console.log(userId);
    let sql = "Update users SET firstname='" + req.body.firstname + "', lastname='" + req.body.lastname + "',  email='" + req.body.email + "', gender='" + req.body.gender + "',  mobileno='" + req.body.mobileno + "', birthdate='" + req.body.birthdate + "', bloodgroup='" + req.body.bloodgroup + "', address='" + req.body.address + "' where userId =" + userId;
    let query = connection.query(sql, (err, results) => {
        if (err) {
            throw err;
        }
        else {
            res.redirect('/user');
        }
    });

}


//<<<------Delete user in database------>>>
exports.appGetdeleteuser = (req, res) => {
    const userId = req.params.userId;
    let sql = `DELETE from users where userId = ${userId}`;
    let query = connection.query(sql, (err, result) => {
        if (err) {
            throw err;
        }
        else {
            res.redirect('/user');
        }
    });
}