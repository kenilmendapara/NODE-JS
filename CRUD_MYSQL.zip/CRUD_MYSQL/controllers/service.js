const connection = require("../models/connection");


//<<<------Display all services------>>>
exports.appGetShowService = (req, res) => {
    let sql = "SELECT * FROM services";
    let query = connection.query(sql, (err, rows) => {
        if (err) {
            throw err;
        }
        else {
            res.render('sindex', {
                title: 'services',
                services: rows
            });
        }
    });
}


//<<<------Add new Service------>>>
exports.appGetAddService = (req, res) => {
    res.render('sadd', {
        title: 'Add Service'
    });
}


//<<<------Insert service in database------>>>
exports.appPostInsertService = (req, res) => {
    console.log(req.body);
    let data = {
        customerName: req.body.customerName,
        vehicleNumber: req.body.vehicleNumber,
        pickUpDate: req.body.pickUpDate,
        dropDate: req.body.dropDate,
        location: req.body.location,
        serviceLocation: req.body.serviceLocation,
        servicePrice: req.body.servicePrice,
        paybleAmount: req.body.paybleAmount

    };
    let sql = "INSERT INTO services SET ?";
    let query = connection.query(sql, data, (err, results) => {
        if (err) {
            throw err;
        }
        else {
            res.redirect('/service');
        }
    });
}

//<<<------Edit service details in database------>>>
exports.appGetEditService = (req, res) => {
    const serviceId = req.params.serviceId;
    console.log(serviceId);
    let sql = `Select * from services where serviceId = ${serviceId}`;
    console.log(sql);
    let query = connection.query(sql, (err, result) => {
        if (err) {
            throw err;
        }
        else {
            res.render('sedit', {
                title: 'Edit Service',
                service: result[0]
            });
        }
    });
}


//<<<------Update service in database------>>>
exports.appPostUpdateService = (req, res) => {
    const serviceId = req.body.serviceId;
    console.log(serviceId);
    let sql = "Update services SET customerName='" + req.body.customerName + "', vehicleNumber='" + req.body.vehicleNumber + "',  pickUpDate='" + req.body.pickUpDate + "', dropDate='" + req.body.dropDate + "',  location='" + req.body.location + "', serviceLocation='" + req.body.serviceLocation + "', servicePrice='" + req.body.servicePrice + "', paybleAmount='" + req.body.paybleAmount + "' where serviceId =" + serviceId;
    let query = connection.query(sql, (err, results) => {
        if (err) {
            throw err;
        }
        else {
            res.redirect('/service');
        }
    });

}


//<<<------Delete service in database------>>>
exports.appGetdeleteservice = (req, res) => {
    const serviceId = req.params.serviceId;
    let sql = `DELETE from services where serviceId = ${serviceId}`;
    let query = connection.query(sql, (err, result) => {
        if (err) {
            throw err;
        }
        else {
            res.redirect('/service');
        }
    });
}