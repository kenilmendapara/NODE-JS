const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const userController = require('./controllers/user');
const serviceController = require('./controllers/service');
const port = 3330;
const app = express();


//<<<------set view engine------>>>
app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));

//<<<------set body-parser------>>>
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use("/home", (req, res) => {
    res.render('home');
})
//<<<------Display all users------>>>
app.get('/user', userController.appGetShowUser);


//<<<------Add new User------>>>
app.get('/user/add', userController.appGetAddUser);


//<<<------Insert user in database------>>>
app.post('/user/save', userController.appPostInsertUser);


//<<<------Edit user details in database------>>>
app.get('/user/edit/:userId', userController.appGetEditUser);


//<<<------Update user in database------>>>
app.post('/user/update', userController.appPostUpdateUser);


//<<<------Delete user in database------>>>
app.get('/user/delete/:userId', userController.appGetdeleteuser);

//<<<------Display all services------>>>
app.get('/service', serviceController.appGetShowService);


//<<<------Add new Service------>>>
app.get('/service/add', serviceController.appGetAddService);


//<<<------Insert service in database------>>>
app.post('/service/save', serviceController.appPostInsertService);


//<<<------Edit service details in database------>>>
app.get('/service/edit/:serviceId', serviceController.appGetEditService);


//<<<------Update service in database------>>>
app.post('/service/update', serviceController.appPostUpdateService);


//<<<------Delete service in database------>>>
app.get('/service/delete/:serviceId', serviceController.appGetdeleteservice);


//<<<------Server Listening------>>>
app.listen(port, () => {
    console.log(`Server is running at port http://localhost:${port}/home`);
});















































